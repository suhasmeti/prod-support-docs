#!/bin/sh
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

JOB_ID="$1"
ACTION_TYPE="$2"
SAMPLE_COUNT="$3"
SAMPLING_INTERVAL="$4"
ACTION_ARGUMENT="$5"

DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ACTIONS_DIR="${DIR}/actions"
ACTION_RESULT_DIR="/tmp/cirrent"
ACTION_RESULT_FILE="${ACTION_RESULT_DIR}/action-${ACTION_TYPE}-${JOB_ID}"

if [ ! -x "${ACTIONS_DIR}/${ACTION_TYPE}" ]; then
    cirrent_cli action_ready "$JOB_ID" "failure" "Handler not found"
    exit 1
fi

mkdir -p "$ACTION_RESULT_DIR"
rm -f "$ACTION_RESULT_FILE"

count=1
while [ $count -le $SAMPLE_COUNT ]; do
    echo "SAMPLE_COUNT=$count" >> "$ACTION_RESULT_FILE"
    date >> "$ACTION_RESULT_FILE"

    (
        "${ACTIONS_DIR}/${ACTION_TYPE}" "$ACTION_ARGUMENT" 2>&1
    ) >> "$ACTION_RESULT_FILE"

    if [ $? -ne 0 ]; then
        cirrent_cli action_ready "$JOB_ID" "failure" "Handler error" "$ACTION_RESULT_FILE"
        exit 1
    fi

    sleep $SAMPLING_INTERVAL
    count=$(expr $count + 1)
done

cirrent_cli action_ready "$JOB_ID" "success" "" "$ACTION_RESULT_FILE"

exit 0
