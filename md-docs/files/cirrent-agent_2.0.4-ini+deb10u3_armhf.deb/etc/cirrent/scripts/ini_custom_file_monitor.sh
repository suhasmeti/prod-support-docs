#!/bin/bash
# $1=PID file path for Cirrent Angent
# $2=Path of log file to monitor
# $3=keyword1
# $4=event1
# $5=keyword2
# $6=event2
# $7=keyword3
# $8=event3
#
# ./ini_custom_file_monitor.sh /var/run/cirrent_agent.pid /etc/cirrent/log/ca_log THREAD-EXCEEDED-PET-CNT Watchdog_Error CONNECTED WiFi_Connected DISCONNECTED WiFi_Disconnected

logfile=$2
keyword1=$3
event1=$4

keyword2=$5
event2=$6

keyword3=$7
event3=$8

tail -F $logfile --pid=$(cat $1) | \
while read line ; do
    if [ -n "$keyword1" ] && [ -n "$event1" ]; then
        echo "$line" | grep -w $keyword1
        if [ $? = 0 ]; then
            cirrent_cli ini_custom event $event1
        fi
    fi

    if [ -n "$keyword2" ] && [ -n "$event2" ]; then
        echo "$line" | grep -w $keyword2
        if [ $? = 0 ]; then
            cirrent_cli ini_custom event $event2
        fi
    fi
    
    if [ -n "$keyword3" ] && [ -n "$event3" ]; then
        echo "$line" | grep -w $keyword3
        if [ $? = 0 ]; then
            cirrent_cli ini_custom event $event3
        fi
    fi
done
