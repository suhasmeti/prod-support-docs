#!/bin/bash
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

TYPE="$1"
STATE_FILE_PREFIX="/tmp/cirrent/ini_custom_ev_state_"

CPU_TEMP_THRESHOLD=60
GPU_TEMP_THRESHOLD=60

# common functions

ini_custom_cmd()
{
    test -n "$3" && cirrent_cli ini_custom "$1" "$2" "$3"
}

report_event_start()
{
    if ! [ -f "${STATE_FILE_PREFIX}$1" ]; then
        ini_custom_cmd event "$1" start
        touch "${STATE_FILE_PREFIX}$1"
    fi
}

report_event_stop()
{
    if [ -f "${STATE_FILE_PREFIX}$1" ]; then
        ini_custom_cmd event "$1" stop
        rm -f "${STATE_FILE_PREFIX}$1"
    fi
}

report_instantaneous_event()
{
    if ! [ -f "${STATE_FILE_PREFIX}$1" ]; then
        cirrent_cli ini_custom event "$1"
        touch "${STATE_FILE_PREFIX}$1"
    fi
}

# attributes

report_serial_no()
{
    SERIAL_NO=$(cat /proc/cpuinfo | grep Serial | cut -d ' ' -f 2)
    ini_custom_cmd attribute "serial_no" "${SERIAL_NO}"
}

report_gpu_firmware()
{
    GPU_FIRMWARE=$(vcgencmd version | grep version | cut -d ' ' -f 2)
    ini_custom_cmd attribute "gpu_firmware" "${GPU_FIRMWARE}"
}

report_model()
{
    MODEL=$(tr -d '\0' </proc/device-tree/model)
    ini_custom_cmd attribute "model" "${MODEL}"
}

# states

report_ethernet_state()
{
    [[ $(cat /sys/class/net/eth0/carrier) = 1 ]] && ETH_PORT='PLUGGED' || ETH_PORT='UNPLUGGED'
    ini_custom_cmd state "eth_port" "${ETH_PORT}"
}

report_usb_state()
{
    # For RPI3 port 1 connected to internal ethernet (smsc95xx)
    # Ports 2..5 are external ports
    for i in 2 3 4 5; do
        [ -d "/sys/bus/usb/devices/1-1.$i" ] && USB_STATE="PLUGGED" || USB_STATE="UNPLUGGED"
        ini_custom_cmd state "usb_port_${i}" "${USB_STATE}"
    done
}

# measurements

report_gpu_temp()
{
    GPU_TEMP=$(vcgencmd measure_temp | egrep -o '[0-9]*\.[0-9]*')
    ini_custom_cmd measurement "gpu_temp" "${GPU_TEMP}"
}

report_gpu_volts()
{
    GPU_VOLTS=$(vcgencmd measure_volts core | egrep -o '[0-9]*\.[0-9]*')
    ini_custom_cmd measurement "gpu_volts" "${GPU_VOLTS}"
}

report_cpu_temp()
{
    CPU_TEMP=$(cat /sys/class/thermal/thermal_zone0/temp)
    ini_custom_cmd measurement "cpu_temp" "$((${CPU_TEMP} / 1000)).${CPU_TEMP: (-3)}"
}

report_cpu_freq()
{
    CPU_FREQ=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq)
    ini_custom_cmd measurement "cpu_freq" "${CPU_FREQ}"
}

report_system_uptime()
{
    SYSTEM_UPTIME=$(cat /proc/uptime | cut -d ' ' -f 1)
    ini_custom_cmd measurement "system_uptime" "${SYSTEM_UPTIME}"
}

# events

report_high_cpu_temp()
{
    CPU_TEMP_INT="$((${CPU_TEMP} / 1000))"
    [ "${CPU_TEMP_INT}" -gt "${CPU_TEMP_THRESHOLD}" ] &&
        report_event_start "high_cpu_temp" ||
        report_event_stop "high_cpu_temp"
}

report_high_gpu_temp()
{
    GPU_TEMP_INT=$(echo "${GPU_TEMP}" | cut -d '.' -f 1)

    [ "${GPU_TEMP_INT}" -gt "${GPU_TEMP_THRESHOLD}" ] &&
        report_event_start "high_gpu_temp" ||
        report_event_stop "high_gpu_temp"
}

report_throttled()
{
    THROTTLED=$(vcgencmd get_throttled | cut -d'=' -f2)

    (( $THROTTLED >> 2 & 1 )) &&
        report_event_start "throttled" ||
        report_event_stop "throttled"

    (( $THROTTLED >> 16 & 1 )) && report_instantaneous_event "under-voltage"
    (( $THROTTLED >> 19 & 1 )) && report_instantaneous_event "temp_limit"
}

case "${TYPE}" in
    attribute)
        report_serial_no
        report_gpu_firmware
        report_model
        ;;

    *)
        # states
        report_ethernet_state
        report_usb_state

        # measurements
        report_gpu_temp
        report_gpu_volts
        report_cpu_temp
        report_cpu_freq
        report_system_uptime

        # events
        report_high_cpu_temp
        report_high_gpu_temp
        report_throttled
        ;;

esac
