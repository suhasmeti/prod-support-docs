#!/bin/sh
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

ACT_LED="/sys/class/leds/led0"
PWR_LED="/sys/class/leds/led1"

act_led_set_state() {
    if grep -vqs "\[none\]" "${ACT_LED}/trigger"; then
	    echo none > "${ACT_LED}/trigger"
	    sleep 1
	fi
    echo "$1" > "${ACT_LED}/brightness"
}

pwr_led_set_timer() {
    modprobe ledtrig-timer
    echo "timer" > "${PWR_LED}/trigger"
    echo "$1" > "${PWR_LED}/delay_on"
    echo "$1" > "${PWR_LED}/delay_off"
}

case "$1" in
    "CONNECTED_PRIVATE")
        act_led_set_state 1
        ;;
    "DISCONNECTED")
        act_led_set_state 0
        ;;
    "READY_FOR_ONBOARDING")
        pwr_led_set_timer 200
        ;;
    "ONBOARDING_DISABLED")
        pwr_led_set_timer 2000
        ;;
    "FAILED_JOIN_PRIVATE_NET")
        i=3
        while [ $i -gt 0 ]; do
            i=$(expr $i - 1)
            act_led_set_state 1
            sleep 0.2
            act_led_set_state 0
            sleep 0.2
        done
        ;;
    *)
        echo "Unknown status $1"
        exit 1
        ;;
esac
