#!/bin/sh
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

if [ "$#" -lt 1 ]; then
  echo "Usage:"
  echo "./personalize.sh <ca_dir>"
  echo "where <ca_dir> is the location of the ca service directory"
  exit 1
fi

CA_DIR=$1
PATH=$PATH:$1/bin

KEYS_DIR=$CA_DIR/storage
CREDENTIALS_FILE=$KEYS_DIR/cloud_creds
CERTS_TMP_FILE=/tmp/cirrent_certs.json
CA_SERVICE_FILE=/etc/init.d/cirrent
PRIVATE_NETWORK_FILE=$CA_DIR/private_networks.bin
CA_STORAGE_DIR=$CA_DIR/storage
CA_CA_CRT_FILE=$CA_STORAGE_DIR/certs.pem

parse_certificates()
{
    CERTS_JSON=$1
    echo "Parsing ${CERTS_JSON}..."

    if jq --version > /dev/null; then
        echo "Using 'jq' to parse  ${CERTS_JSON}"
    else
        echo "jq not installed - skip certs update."
        return 1
    fi

    CA_CRT_FILENAME=$(basename ${CA_CA_CRT_FILE})
    mkdir -p ${CA_STORAGE_DIR}

    for i in $(seq 0 3); do
        CERT_FILE_NAME=$(cat  ${CERTS_JSON} | jq -r ".certs[$i].cert_file_name")
        CERT_TYPE=$(cat ${CERTS_JSON} | jq -r ".certs[$i].cert_type")
        CERT_BODY=$(cat ${CERTS_JSON} | jq -r ".certs[$i].cert")
        case ${CERT_FILE_NAME} in
            ${CA_CRT_FILENAME})
                echo "Updating ${CA_CA_CRT_FILE}, type: ${CERT_TYPE}."
                printf "%s" "${CERT_BODY}" > ${CA_CA_CRT_FILE}
                ;;

        esac
    done
}

echo 'Now we will set up the credentials for this device'
# make sure the directory exists
mkdir -p $KEYS_DIR

if [ -f $CREDENTIALS_FILE ]; then
   # read the cloud_creds file
   CREDENTIALS=$(cat $CREDENTIALS_FILE)
   OLD_DEVICE_ID=$(echo "$CREDENTIALS" | grep DeviceId: | awk '{print $2}')
   OLD_ACCOUNT_ID=$(echo "$CREDENTIALS" | grep AccountId: | awk '{print $2}')
   OLD_DEVICE_SECRET=$(echo "$CREDENTIALS" | grep DeviceSecret: | awk '{print $2}')

   # get input from the user
   read -p "Device id <$OLD_DEVICE_ID> (enter to keep the same):" DEVICE_ID
   read -p "Secret <$OLD_DEVICE_SECRET> (enter to keep the same):" DEVICE_SECRET
   read -p "Account id <$OLD_ACCOUNT_ID> (enter to keep the same):" ACCOUNT_ID

   if [ -z $DEVICE_ID ]; then
      DEVICE_ID=$OLD_DEVICE_ID
   fi
   if [ -z $DEVICE_SECRET ]; then
      DEVICE_SECRET=$OLD_DEVICE_SECRET
   fi
   if [ -z $ACCOUNT_ID ]; then
      ACCOUNT_ID=$OLD_ACCOUNT_ID
   fi
else
   read -p "Device id:" DEVICE_ID
   read -p "Secret:" DEVICE_SECRET
   read -p "Account id:" ACCOUNT_ID
fi

# write the cloud_creds file
cat <<EOF >$CREDENTIALS_FILE
[Device Credential]
DeviceId:     $DEVICE_ID
DeviceSecret: $DEVICE_SECRET
AccountId:    $ACCOUNT_ID
EOF

CURL_JQ_INSTALLED="NO"

curl --version > /dev/null 2>&1
CURL_INSTALLED=$?
jq --version > /dev/null 2>&1
JQ_INSTALLED=$?
if [ "$CURL_INSTALLED" -eq 0 ] && [ "$JQ_INSTALLED" -eq 0 ]; then
    CURL_JQ_INSTALLED="YES"
fi

if [ "$CURL_JQ_INSTALLED" = "NO" ]; then
    echo "Congratulations! You do not have curl or jq but everything looks good."
    echo "You can proceed with starting the cirrent agent."
    exit 0
fi

secret_length=${#DEVICE_SECRET}
apikey="$(expr substr $DEVICE_SECRET $((secret_length / 4 + 1))  $((secret_length - 2 * (secret_length / 4))))"
USER_PASSWORD="$ACCOUNT_ID"_"$DEVICE_ID":$apikey

echo "Downloading CA Certificates"
curl -s https://dev.cirrentsystems.com/2016-01/cert/0 --basic --user $USER_PASSWORD --max-time 10 --retry 3 > $CERTS_TMP_FILE
if [ $? -ne 0 ]; then
    echo "Failed to download certificates."
else
    echo "Parse certificates and update cirrent_agent.conf with new path."
    parse_certificates $CERTS_TMP_FILE
fi

echo "Personalization completed successfully."
