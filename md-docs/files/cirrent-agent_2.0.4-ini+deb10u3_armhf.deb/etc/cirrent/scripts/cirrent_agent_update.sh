#!/bin/sh
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

OTA_URL="$1"
JOB_ID="$2"

OTA_DIR=/opt/cirrent
CA_DIR=/etc/cirrent

OTA_LOG="${OTA_DIR}/ota.log"
OTA_DEB="${OTA_DIR}/cirrent-agent_ota-update_armhf.deb"
BACKUP_DEB="${OTA_DIR}/cirrent-agent_ota-backup_armhf.deb"
UPDATE_HELPER="$(mktemp -d)/cirrent_agent_update_helper.sh"

TIMEOUT=60

init_check()
{
    if [ -f "$OTA_DEB" ]; then
        rm "$OTA_DEB"
        revert "Prev update detected"
    fi
    exit 0
}

report_failure()
{
    rm -f $OTA_DEB
    report_result "failure" "$1"
}

report_result()
{
    timeout $TIMEOUT cirrent_cli action_ready "$JOB_ID" "$1" "$2" "$OTA_LOG"
    timeout 90 $UPDATE_HELPER wait_action_file_rm
    retVal=$?

    if [ $retVal -ne 0 ]; then
        timeout $TIMEOUT $UPDATE_HELPER revert_package "$BACKUP_DEB"
        timeout $TIMEOUT $UPDATE_HELPER upload_log "$OTA_LOG"
        exit 1
    fi

    exit 0
}

revert()
{
    rm -f $OTA_DEB
    timeout $TIMEOUT $UPDATE_HELPER revert_package "$BACKUP_DEB"
    report_failure "$1"
}

if [ "$1" != "init_check" -a "$1" != "revert" ]; then
    rm -f $OTA_LOG
fi

[ -n "$1" ] && ((
    set -x

    cp -f "${CA_DIR}/scripts/cirrent_agent_update_helper.sh" "$UPDATE_HELPER"

    case "$1" in
        init_check)
            init_check
            ;;
        revert)
            revert "CA service start error"
            ;;
    esac

    timeout $TIMEOUT $UPDATE_HELPER download_file "$OTA_DEB" "$OTA_URL"

    dpkg-deb --info $OTA_DEB || report_failure "Download error"

    timeout $TIMEOUT $UPDATE_HELPER install_package "$OTA_DEB" || revert "Install error"

    rm "$OTA_DEB"

    timeout $TIMEOUT $UPDATE_HELPER restart_service || revert "CA start error"

    sleep 30

    report_result "success" ""
) 2>&1 ) >> $OTA_LOG
