#!/bin/sh
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

OTA_URL="$1"
JOB_ID="$2"

OTA_DIR=/opt/cirrent
CA_DIR=/etc/cirrent
FW_DIR=/lib/firmware/brcm

OTA_LOG="${OTA_DIR}/ota_wifi_fw_update.log"
WIFI_FW="${FW_DIR}/brcmfmac43430-sdio.bin"
BACKUP_WIFI_FW="${OTA_DIR}/wifi_fw.bin.backup"
UPDATE_HELPER="${CA_DIR}/scripts/cirrent_agent_update_helper.sh"
REASON_FILE="${CA_DIR}/storage/action_reason"

TIMEOUT=60

test_interface()
{
    ip link show wlan0 > /dev/null 2>&1
}

init_check()
{
    if [ -f $BACKUP_WIFI_FW ]; then
        test_interface || revert "No Wi-Fi interface"
        timeout $TIMEOUT $UPDATE_HELPER ca_start_check || revert "CA start error"
    fi

    exit 0
}

apply()
{
    rm -f $BACKUP_WIFI_FW

    exit 0
}

report_failure()
{
    mv -f $BACKUP_WIFI_FW $WIFI_FW

    report_result "failure" "$1"
}

report_result()
{
    timeout $TIMEOUT cirrent_cli action_ready "$JOB_ID" "$1" "$2" "$OTA_LOG"

    exit 0
}

revert()
{
    mv -f $BACKUP_WIFI_FW $WIFI_FW

    printf "%s\0" "$1" > $REASON_FILE

    sleep 1 && reboot
}

mkdir -p $OTA_DIR

((
    set -x

    [ -n "$1" ] || report_failure "No argument"

    case "$1" in
        init_check)
            init_check
            ;;
        revert)
            revert "$2"
            ;;
        apply)
            apply
            ;;
        *)
            : > $OTA_LOG

            mv -f $WIFI_FW $BACKUP_WIFI_FW

            timeout $TIMEOUT $UPDATE_HELPER download_file "$WIFI_FW" "$OTA_URL" || report_failure "Download error"
            [ -s $WIFI_FW ] || report_failure "Invalid firmware"

            sleep 1 && reboot
    esac
) 2>&1 ) >> $OTA_LOG
