#!/bin/sh
#
# Copyright (C) 2021, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

CA_DIR=/etc/cirrent

ACTION_BIN="${CA_DIR}/storage/action.bin"
CA_CREDENTIALS_KEY="${CA_DIR}/storage/cloud_creds"

install_deb()
{
    yes | dpkg --install "$1" || return 1
}

fix_deps()
{
    apt-get -qq update
    apt-get -qqyf install

    return 1
}

ca_start_check()
{
    local i=15
    while [ $i -gt 0 ]; do
        local i=$(expr $i - 1)

        /etc/init.d/cirrent status
        cirrent_cli version
        ret=$?

        if [ $ret -eq 0 ]; then
            return 0
        fi

        sleep 1;
    done

    return 1
}

restart_service()
{
    /etc/init.d/cirrent restart || return 1
    date

    ca_start_check

    return $?
}

get_cred_value()
{
    value=$(grep "$1" "$CA_CREDENTIALS_KEY" | cut -d':' -f2-)
    echo -n $value
}

get_cred_password()
{
    len=$(expr length "$1")
    expr substr "$1" $(expr $len / 4 + 1) $(expr $len / 2)
}

upload_log()
{
    local account="$(get_cred_value "AccountId")"
    local device="$(get_cred_value "DeviceId")"
    local secret="$(get_cred_value "DeviceSecret")"

    [ -n "$account" -a -n "$device" -a -n "$secret" ] || return 1
    local password="$(get_cred_password "$secret")"

    local i=3
    while [ $i -gt 0 ]; do
        local i=$(expr $i - 1)
        curl --silent --show-error -H 'Content-Type: text/plain' -X PUT \
            --user "${account}_${device}:${password}" \
            "https://dev.cirrentsystems.com/2016-01/log" \
            --data-binary "@${1}" && break
    done
}

revert_package()
{
    install_deb "$1"
    restart_service
}

case "$1" in
    download_file)
        wget -nv -O "$2" "$3"
        ;;
    install_package)
        install_deb "$2" || fix_deps || install_deb "$2"
        ;;
    restart_service)
        restart_service
        ;;
    ca_start_check)
        ca_start_check
        ;;
    upload_log)
        upload_log "$2"
        ;;
    wait_action_file_rm)
        while [ -f "$ACTION_BIN" ]; do
            sleep 1;
        done
        ;;
    revert_package)
        revert_package "$2"
        ;;
    *)
        ;;
esac
